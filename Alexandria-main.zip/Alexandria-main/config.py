class Config:
    SQLALCHEMY_DATABASE_URI = "mysql+mysqlconnector://root:@localhost:3307/alexandria"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    